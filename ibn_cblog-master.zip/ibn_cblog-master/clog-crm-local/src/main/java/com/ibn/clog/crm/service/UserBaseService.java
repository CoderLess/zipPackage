package com.ibn.clog.crm.service;


import com.ibn.clog.crm.domain.UserBaseDTO;
import com.ibn.exception.IbnException;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.crm.service
 * @author： RenBin
 * @createTime：2019/12/13 13:38
 */
public interface UserBaseService {
    void userSave(UserBaseDTO userBaseDTO) throws IbnException;
    UserBaseDTO userQuery(UserBaseDTO userBaseDTO) throws IbnException;
}
