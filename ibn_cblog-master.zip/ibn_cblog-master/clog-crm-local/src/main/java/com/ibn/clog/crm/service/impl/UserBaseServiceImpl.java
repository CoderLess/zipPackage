package com.ibn.clog.crm.service.impl;

import com.ibn.clog.crm.dao.UserBaseDao;
import com.ibn.clog.crm.domain.UserBaseDTO;
import com.ibn.clog.crm.entity.UserBaseDO;
import com.ibn.clog.crm.service.UserBaseService;
import com.ibn.exception.IbnException;
import org.checkerframework.checker.units.qual.A;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.crm.service.impl
 * @author： RenBin
 * @createTime：2019/12/13 13:42
 */
@Service("userBaseService")
public class UserBaseServiceImpl implements UserBaseService {
    @Autowired
    private UserBaseDao userBaseDao;

    @Override
    public void userSave(UserBaseDTO userBaseDTO) throws IbnException {
        UserBaseDO userBaseDO = new UserBaseDO();
        BeanUtils.copyProperties(userBaseDTO, userBaseDO);
        userBaseDao.insertUserBase(userBaseDO);
    }

    @Override
    public UserBaseDTO userQuery(UserBaseDTO userBaseDTO) throws IbnException {
        if (null == userBaseDTO) {
            throw new IbnException("参数异常");
        }
        UserBaseDO userBaseDO = new UserBaseDO();
        BeanUtils.copyProperties(userBaseDTO, userBaseDO);
        userBaseDO= userBaseDao.queryUserBase(userBaseDO);
        if (null == userBaseDO) {
            return null;
        }
        BeanUtils.copyProperties(userBaseDO,userBaseDTO);
        return userBaseDTO;
    }
}
