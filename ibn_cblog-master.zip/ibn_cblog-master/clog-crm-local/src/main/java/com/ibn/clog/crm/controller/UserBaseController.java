package com.ibn.clog.crm.controller;

import com.ibn.clog.crm.domain.UserBaseDTO;
import com.ibn.clog.crm.service.UserBaseService;
import com.ibn.entity.ResultInfo;
import com.ibn.exception.IbnException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.crm.controller
 * @author： RenBin
 * @createTime：2019/12/13 13:04
 */
@RestController
@RequestMapping("users")
public class UserBaseController {
    @Autowired
    private UserBaseService userBaseService;
    @RequestMapping(method = RequestMethod.POST)
    public ResultInfo<Object> saveUser(@RequestBody UserBaseDTO userBaseDTO) {
        try {
            userBaseService.userSave(userBaseDTO);
        } catch (IbnException e) {
            return new ResultInfo<>().error("保存用户信息失败");
        }
        return new ResultInfo<>().success("保存用户信息成功");
    }
    @RequestMapping(method = RequestMethod.GET)
    public ResultInfo<Object> queryUser(UserBaseDTO userBaseDTO) {
        UserBaseDTO userBaseDTOForResult;
        try {
            userBaseDTOForResult=userBaseService.userQuery(userBaseDTO);
        } catch (IbnException e) {
            return new ResultInfo<>().error("保存用户信息失败");
        }
        return new ResultInfo<>().success(userBaseDTOForResult,"保存用户信息成功");
    }
}
