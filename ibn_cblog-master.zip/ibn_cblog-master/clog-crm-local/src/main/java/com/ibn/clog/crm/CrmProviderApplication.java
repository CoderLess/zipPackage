package com.ibn.clog.crm;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.crm
 * @author： RenBin
 * @createTime：2019/12/13 12:43
 */
@SpringBootApplication
@MapperScan({"com.ibn.clog.crm.dao"})
public class CrmProviderApplication {
    public static void main(String[] args) {
        SpringApplication.run(CrmProviderApplication.class, args);
    }
}
