package com.ibn.clog.crm.dao;

import com.ibn.clog.crm.entity.UserBaseDO;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.crm.dao
 * @author： RenBin
 * @createTime：2019/12/18 9:48
 */
public interface UserBaseDao {
    int insertUserBase(UserBaseDO userBaseDO);

    UserBaseDO queryUserBase(UserBaseDO userBaseDO);
}
