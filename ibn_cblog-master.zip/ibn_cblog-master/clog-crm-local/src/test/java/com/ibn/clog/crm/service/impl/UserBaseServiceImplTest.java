package com.ibn.clog.crm.service.impl;

import com.ibn.clog.crm.domain.UserBaseDTO;
import com.ibn.clog.crm.service.UserBaseService;
import com.ibn.exception.IbnException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UserBaseServiceImplTest {
    @Autowired
    private UserBaseService userBaseService;
    @Test
    public void userRegister() throws IbnException {
        UserBaseDTO userBaseDTO = new UserBaseDTO();
        userBaseDTO.setPassWord("123");
        userBaseDTO.setUserName("zhangsan");
        userBaseService.userSave(userBaseDTO);
    }
}