package com.ibn.clog.crm.entity;

import com.ibn.entity.BaseDO;
import lombok.Data;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.crm.entity
 * @author： RenBin
 * @createTime：2019/12/13 12:37
 */
@Data
public class UserBaseDO extends BaseDO {
    /**
     * @description: 主键
     * @author：RenBin
     * @createTime：2019/12/18 9:46
     */
    private Long id;
    /**
     * @description: 用户名
     * @author：RenBin
     * @createTime：2019/12/18 9:46
     */
    private String userName;
    /**
     * @description: 密码
     * @author：RenBin
     * @createTime：2019/12/18 9:46
     */
    private String passWord;
}
