package com.ibn.clog.crm.domain;

import lombok.Data;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.crm.domain
 * @author： RenBin
 * @createTime：2019/12/18 9:45
 */
@Data
public class UserBaseDTO {
    /**
     * @description: 主键
     * @author：RenBin
     * @createTime：2019/12/18 9:46
     */
    private Long id;
    /**
     * @description: 用户名
     * @author：RenBin
     * @createTime：2019/12/18 9:46
     */
    private String userName;
    /**
     * @description: 密码
     * @author：RenBin
     * @createTime：2019/12/18 9:46
     */
    private String passWord;
}
