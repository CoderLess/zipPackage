package com.ibn.ienum;

/**
 * @version 1.0
 * @projectName：cblog
 * @description: 返回状态码
 * @see:com.ibn.ienum
 * @author：RenBin
 * @createTime：2019/12/10 15:29
 **/
public enum StatusCodeEnum {

    OK(200, "请求成功"),
    ERROR(500, "服务端错误");

    private Integer code;
    private String desc;

    StatusCodeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public Integer getCode() {
        return code;
    }
}
