package com.ibn.exception;

/**
 * @version 1.0
 * @description:
 * @projectName：cblog
 * @see: com.ibn.exception
 * @author： RenBin
 * @createTime：2019/12/11 17:17
 */
public class IbnException extends Exception {
    private String message;

    public IbnException(String message) {
        super(message);
    }
}
