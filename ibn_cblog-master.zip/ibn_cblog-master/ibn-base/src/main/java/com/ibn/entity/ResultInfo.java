package com.ibn.entity;

import com.ibn.ienum.StatusCodeEnum;
import lombok.Data;

import java.io.Serializable;

/**
 * @version 1.0
 * @projectName：cblog
 * @description: 请求返回结果
 * @see:com.ibn.entity
 * @author：RenBin
 * @createTime：2019/12/10 15:20
 **/
@Data
public class ResultInfo<T> implements Serializable {
    private static final long serialVersionUID = 6793350277616007958L;

    private Integer status;
    private String message;
    private T data;

    public ResultInfo success(String message) {
        this.status = StatusCodeEnum.OK.getCode();
        this.message = message;
        return this;
    }

    public ResultInfo<T> success(T response,String message) {
        this.status = StatusCodeEnum.OK.getCode();
        this.message = message;
        this.data = response;
        return this;
    }

    public ResultInfo error(String message) {
        this.status = StatusCodeEnum.ERROR.getCode();
        this.message = message;
        return this;
    }
}
