package com.ibn.ienum;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.ienum
 * @author： RenBin
 * @createTime：2019/12/18 14:14
 */
public enum  HeaderEnum {

    AUTHORIZATION("存放token", "Authorization");
    /**
     * @description: 枚举的描述
     * @author：RenBin
     * @createTime：2019/12/18 14:15
     */
    private String desc;
    /**
     * @description: 枚举值
     * @author：RenBin
     * @createTime：2019/12/18 14:15
     */
    private String values;

    HeaderEnum(String desc, String values) {
        this.desc = desc;
        this.values = values;
    }

    public String getDesc() {
        return desc;
    }

    public String getValues() {
        return values;
    }

}
