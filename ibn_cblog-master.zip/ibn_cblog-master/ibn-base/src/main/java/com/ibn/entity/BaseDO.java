package com.ibn.entity;

import com.ibn.util.AbstractObject;

import java.io.Serializable;

/**
 * @version 1.0
 * @description:
 * @projectName：cblog
 * @see: com.ibn.entity
 * @author： RenBin
 * @createTime：2019/12/9 11:16
 */
public class BaseDO extends AbstractObject implements Serializable {

    private static final long serialVersionUID = 85311197323162151L;

}
