package com.ibn.entity;

import com.ibn.util.AbstractObject;

import java.io.Serializable;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.entity
 * @author： RenBin
 * @createTime：2019/12/13 13:33
 */
public class BaseVO extends AbstractObject implements Serializable {
    private static final long serialVersionUID = -5417411115452955385L;
}
