package com.ibn.util;

/**
 * @version 1.0
 * @description:
 * @projectName：cblog
 * @see: com.ibn.util
 * @author： RenBin
 * @createTime：2019/12/9 11:18
 */
public class AbstractObject {

    /**
     * @description: 浅度克隆
     * @author：RenBin
     * @createTime：2019/12/9 11:25
     */
    public <T> T clone(Class<T> clazz) throws InstantiationException, IllegalAccessException {
        T target = clazz.newInstance();
        BeanUtils.copyProperties(this, target);
        return target;
    }

    /**
     * @description: 浅度克隆
     * @author：RenBin
     * @createTime：2019/12/9 11:25
     */
    public <T> T clone(T target) {
        BeanUtils.copyProperties(this, target);
        return target;
    }


}