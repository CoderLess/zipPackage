package com.ibn.clog.article.util;

import com.alibaba.fastjson.JSON;
import com.ibn.clog.article.entity.ArticleDO;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.common.xcontent.XContentType;

/**
 * @version 1.0
 * @description:
 * @projectName：cblog
 * @see: com.ibn.clog.article.util
 * @author： RenBin
 * @createTime：2019/12/9 11:52
 */
public class ElasticSearchUtil {
    /**
     * @description: 创建一个添加的请求
     * @author：RenBin
     * @createTime：2019/12/4 17:49
     */
    public static IndexRequest createIndexRequest(String indexName, ArticleDO articleDO) {
        IndexRequest indexRequest = new IndexRequest(indexName);
        String jsonString = JSON.toJSONString(articleDO);
        indexRequest.source(jsonString, XContentType.JSON);
        return indexRequest;
    }
}
