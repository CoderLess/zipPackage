package com.ibn.clog.article.config;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @version 1.0
 * @projectName：cblog
 * @description: es客户端
 * @see:com.ibn.clog.config
 * @author：RenBin
 * @createTime：2019/12/10 15:05
 **/
@Configuration
public class ElasticSearchClient {

    @Bean
    public RestHighLevelClient createClient() {
        RestHighLevelClient client = new RestHighLevelClient(
                RestClient.builder(
                        new HttpHost("192.167.12.238", 9200, "http")));
        return client;
    }
}
