package com.ibn.clog.article.impl;

import com.ibn.clog.article.domain.ArticleDTO;
import com.ibn.clog.article.entity.ArticleDO;
import com.ibn.clog.mgt.service.ArticleService;
import com.ibn.clog.article.util.ElasticSearchUtil;
import com.ibn.exception.IbnException;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.support.WriteRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;

/**
 * @version 1.0
 * @description:
 * @projectName：cblog
 * @see: ArticleService.impl
 * @author： RenBin
 * @createTime：2019/12/9 11:13
 */
@Service("articleService")
public class ArticleServiceImpl implements ArticleService {
    private static final String ARTICLE_BASE_INDEX = "article";
    private static final Logger logger = LoggerFactory.getLogger(ArticleServiceImpl.class);
    @Autowired
    private RestHighLevelClient restHighLevelClient;

    @Override
    public void insertArticle(ArticleDTO articleDTO) throws IbnException {
        if (null == articleDTO) {
            return;
        }
        ArticleDO articleDO = new ArticleDO();
        BeanUtils.copyProperties(articleDTO, articleDO);
        IndexResponse indexResponse;
        IndexRequest indexRequest = ElasticSearchUtil.createIndexRequest(ARTICLE_BASE_INDEX, articleDO);
        // 强制刷新相关的主分片和副分片（而不是整个索引），使更新的分片状态变为可搜索
        indexRequest.setRefreshPolicy(WriteRequest.RefreshPolicy.IMMEDIATE);
        try {
            indexResponse = restHighLevelClient.index(indexRequest, RequestOptions.DEFAULT);
            if (null != indexResponse) {

            }
        } catch (IOException e) {
            logger.error("添加数据失败!", e);
            throw new IbnException("添加数据失败");
        }
    }
}
