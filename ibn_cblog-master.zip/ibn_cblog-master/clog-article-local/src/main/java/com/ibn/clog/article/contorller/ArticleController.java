package com.ibn.clog.article.contorller;

import com.ibn.clog.article.domain.ArticleDTO;
import com.ibn.clog.mgt.service.ArticleService;
import com.ibn.entity.ResultInfo;
import com.ibn.exception.IbnException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @version 1.0
 * @projectName：cblog
 * @description: 文章的控制类
 * @see:com.ibn.clog.contorller
 * @author：RenBin
 * @createTime：2019/12/10 15:15
 **/
@RestController
@RequestMapping("articles")
public class ArticleController {
    @Autowired
    private ArticleService articleService;

    @RequestMapping(method = RequestMethod.POST)
    public ResultInfo<String> saveArticle(ArticleDTO articleDTO) {
        ResultInfo<String> resultInfo;
        try {
            articleService.insertArticle(articleDTO);
            resultInfo = new ResultInfo<>().success("添加成功");
        } catch (IbnException e) {
            e.printStackTrace();
            resultInfo = new ResultInfo<>().error("添加失败");
        }
        return resultInfo;
    }
    @RequestMapping(method = RequestMethod.GET)
    public ResultInfo<String> saveArticle() {
        return new ResultInfo<>().success("test:"+System.currentTimeMillis());
    }
}
