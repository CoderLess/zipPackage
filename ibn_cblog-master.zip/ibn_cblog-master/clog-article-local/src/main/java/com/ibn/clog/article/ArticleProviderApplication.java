package com.ibn.clog.article;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @version 1.0
 * @projectName：cblog
 * @description: 启动类
 * @see:com.ibn.clog
 * @author：RenBin
 * @createTime：2019/12/9 18:04
 **/
@SpringBootApplication
public class ArticleProviderApplication {
    public static void main(String[] args) {
        SpringApplication.run(ArticleProviderApplication.class, args);
    }
}
