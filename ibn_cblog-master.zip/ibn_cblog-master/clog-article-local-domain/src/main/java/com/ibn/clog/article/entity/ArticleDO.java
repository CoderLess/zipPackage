package com.ibn.clog.article.entity;

import lombok.Data;

/**
 * @version 1.0
 * @description:
 * @projectName：cblog
 * @see: com.ibn.clog.entity
 * @author： RenBin
 * @createTime：2019/12/9 10:00
 */
@Data
public class ArticleDO {
    private Long id;
    private String title;
    private String content;
}
