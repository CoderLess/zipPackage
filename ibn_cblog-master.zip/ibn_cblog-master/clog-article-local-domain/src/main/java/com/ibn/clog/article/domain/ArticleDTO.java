package com.ibn.clog.article.domain;

import com.ibn.entity.BaseDO;
import lombok.Data;

/**
 * @version 1.0
 * @description:
 * @projectName：cblog
 * @see: com.ibn.clog.domain
 * @author： RenBin
 * @createTime：2019/12/9 11:15
 */
@Data
public class ArticleDTO extends BaseDO {
    private Long id;
    private String title;
    private String content;
}
