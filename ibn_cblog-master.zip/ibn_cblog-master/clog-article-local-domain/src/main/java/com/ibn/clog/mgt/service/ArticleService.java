package com.ibn.clog.mgt.service;


import com.ibn.clog.article.domain.ArticleDTO;
import com.ibn.exception.IbnException;

/**
 * @version 1.0
 * @description:
 * @projectName：cblog
 * @see: com.ibn.clog.domain
 * @author： RenBin
 * @createTime：2019/12/9 11:33
 */
public interface ArticleService {
    void insertArticle(ArticleDTO articleDTO) throws IbnException;
}
