package com.ibn.clog.mgt.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/**
 * RSA工具类
 *
 * @author lucas
 */
public class RSACryptographyUtil {

    private static Logger logger = LoggerFactory.getLogger(RSACryptographyUtil.class);

    /**
     * @description: 将base64编码后的公钥字符串转成PublicKey实例.
     * @author：RenBin
     * @createTime：2019/12/18 15:01
     */
    public static PublicKey getPublicKey(String publicKey) {
        try {
            byte[] keyBytes = Base64.getDecoder().decode(publicKey.getBytes());
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            return keyFactory.generatePublic(keySpec);
        } catch (Exception e) {
            String msg = String.format("获取PublicKey实例失败:%s", publicKey);
            logger.error(msg, e);
        }
        return null;
    }

    /**
     * @description: 将base64编码后的私钥字符串转成PrivateKey实例.
     * @author：RenBin
     * @createTime：2019/12/18 15:01
     */
    public static PrivateKey getPrivateKey(String privateKey) {
        try {
            byte[] keyBytes = Base64.getDecoder().decode(privateKey.getBytes());
            PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            return keyFactory.generatePrivate(keySpec);
        } catch (Exception e) {
            String msg = String.format("获取PublicKey实例失败:%s", privateKey);
            logger.error(msg, e);
        }
        return null;
    }
}