package com.ibn.clog.mgt.service;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.service
 * @author： RenBin
 * @createTime：2019/12/18 8:13
 */
public interface ImageCodeService {
    /**
     * @description: 获取图片
     * @author：RenBin
     * @createTime：2019/12/13 14:54
     */
    BufferedImage getImage();
    /**
     * @description: 获取验证码的值
     * @author：RenBin
     * @createTime：2019/12/13 14:54
     */
    String getText();
    /**
     * @description: 输出到指定的流中
     * @author：RenBin
     * @createTime：2019/12/13 14:54
     */
    void output(BufferedImage image, OutputStream out) throws IOException;
    /**
     * @description: 输出到指定文件
     * @author：RenBin
     * @createTime：2019/12/13 14:54
     */
    void outputImage(BufferedImage bi,String imageName);
}
