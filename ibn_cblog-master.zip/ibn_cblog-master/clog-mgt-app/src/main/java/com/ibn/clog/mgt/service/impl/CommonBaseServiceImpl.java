package com.ibn.clog.mgt.service.impl;

import com.ibn.clog.mgt.service.CommonBaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.mgt.service.impl
 * @author： RenBin
 * @createTime：2019/12/18 16:46
 */
@Service("commonBaseService")
public class CommonBaseServiceImpl implements CommonBaseService {
    @Autowired
    private RedisTemplate redisTemplate;
    @Override
    public Boolean checkImageCode(String token, String code) {
        String value= (String) redisTemplate.opsForValue().get(token);
        if (null != value && value.equalsIgnoreCase(code)) {
            return true;
        }
        return false;
    }
}
