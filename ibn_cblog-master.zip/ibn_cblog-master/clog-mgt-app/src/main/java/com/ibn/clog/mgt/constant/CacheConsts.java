package com.ibn.clog.mgt.constant;

/**
 * @version 1.0
 * @description: ：缓存相关常量
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.mgt.constant
 * @author： RenBin
 * @createTime：2019/12/19 8:50
 */
public class CacheConsts {
    /**
     * @description: 验证码缓存前缀
     * @author：RenBin
     * @createTime：2019/12/19 8:53
     */
    public static final String IMAGE_CODE = "imageCode_";
}
