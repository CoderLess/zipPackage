package com.ibn.clog.mgt.vo;

import lombok.Data;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.vo
 * @author： RenBin
 * @createTime：2019/12/18 8:44
 */
@Data
public class UserBaseVO {
    private String userName;
    private String passWord;
    private String repassWord;
    private String validateCode;
}
