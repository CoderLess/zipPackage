package com.ibn.clog.mgt.interceptor;

import com.ibn.clog.mgt.anno.NeedLogin;
import com.ibn.clog.mgt.util.JwtUtil;
import com.ibn.exception.IbnException;
import org.springframework.util.StringUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.mgt.interceptor
 * @author： RenBin
 * @createTime：2019/12/18 14:39
 */


public class AuthenticationInterceptor implements HandlerInterceptor {

    /**
     * @description: 预处理回调方法，实现处理器的预处理（如检查登陆），第三个参数为响应的处理器，自定义Controller
     * 返回值：true表示继续流程（如调用下一个拦截器或处理器）；
     * false表示流程中断（如登录检查失败），不会继续调用其他的拦截器或处理器，此时我们需要通过response来产生响应；
     * @author：RenBin
     * @createTime：2019/12/18 14:40
     */
    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object object) throws Exception {
        HandlerMethod handlerMethod = (HandlerMethod) object;
        Method method = handlerMethod.getMethod();
        NeedLogin needLogin = method.getAnnotation(NeedLogin.class);
        //检查方法是否有NeedLogin注解，无则跳过认证
        if (!method.isAnnotationPresent(NeedLogin.class)||!needLogin.required()) {
            return true;
        }

        // 从HTTP请求头中获取TOKEN信息
        String token = httpServletRequest.getHeader("Authorization");
        // 检查TOKEN
        if (!checkToken(token)) {
            return false;
        }

        // HTTP请求头中TOKEN解析出的用户信息
        Long uid = JwtUtil.getUserId(token);
        String userName = JwtUtil.getUserName(token);

        // 组装用户信息到REQUEST中
        Map<String, Object> currentUser = new HashMap<>(16);
        currentUser.put("userId", uid);
        currentUser.put("userName", userName);
        httpServletRequest.setAttribute("currentUser", currentUser);
        return true;
    }

    /**
     * @description: 后处理回调方法，
     * 实现处理器的后处理（但在渲染视图之前），
     * 此时我们可以通过modelAndView（模型和视图对象）对模型数据进行处理或对视图进行处理，
     * modelAndView也可能为null。
     * @author：RenBin
     * @createTime：2019/12/18 15:18
     */
    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object object, ModelAndView modelAndView) throws Exception {
    }

    /**
     * @description: 整个请求处理完毕回调方法，即在视图渲染完毕时回调，
     * 如性能监控中我们可以在此记录结束时间并输出消耗时间，
     * 还可以进行一些资源清理，类似于try-catch-finally中的finally，但仅调用处理器执行链中
     * @author：RenBin
     * @createTime：2019/12/18 15:19
     */
    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
    }

    /**
     * @description: 检查TOKEN
     * @author：RenBin
     * @createTime：2019/12/18 15:20
     */
    private boolean checkToken(String token) throws IbnException {
        // ------------------------认证------------开始-----------------
        if (null == token) {
            return false;
        }
        // HTTP请求头中TOKEN解析出的用户信息
        String userName = JwtUtil.getUserName(token);
        Long userId = JwtUtil.getUserId(token);
        //        long expireIn = JwtUtil.getExpireIn(token);
        // REDIS服务器中TOKEN解析出的用户信息

        if (StringUtils.isEmpty(userName) || null != userId) {
            return false;
        }

        // 判断TOKEN是否过期
        //        if (expireIn != expireInInRedis) {
        //            return false;
        //        }
//        if (expireIn < System.currentTimeMillis()) {
//            return false;
//        }
        // ------------------------认证------------结束-----------------
        return true;
    }

}
