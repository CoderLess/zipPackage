package com.ibn.clog.mgt.service;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.mgt.service
 * @author： RenBin
 * @createTime：2019/12/18 16:46
 */
public interface CommonBaseService {
    Boolean checkImageCode(String token, String code);
}
