package com.ibn.clog.mgt.controller;

import com.ibn.clog.mgt.constant.CacheConsts;
import com.ibn.clog.mgt.service.ImageCodeService;
import com.ibn.clog.mgt.util.MD5Util;
import com.ibn.ienum.HeaderEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.crm.controller
 * @author： RenBin
 * @createTime：2019/12/13 14:14
 */
@RestController
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class CommonBaseController {
    @Autowired
    private ImageCodeService imageCodeService;
    @Autowired
    private RedisTemplate redisTemplate;
    private static Logger logger = LoggerFactory.getLogger(CommonBaseController.class);

    @RequestMapping(method = RequestMethod.GET, path = "imageCode")
    public void getImageCode(HttpServletResponse response) {
        BufferedImage bufferedImage = imageCodeService.getImage();
        response.addHeader("Access-Control-Expose-Headers", HeaderEnum.AUTHORIZATION.getValues());
        String token=MD5Util.getMd5Code(UUID.randomUUID().toString());
        response.addHeader(HeaderEnum.AUTHORIZATION.getValues(), token);
        try {
            imageCodeService.output(bufferedImage, response.getOutputStream());
        } catch (IOException e) {
            logger.error("获取验证码失败", e);
        }
        redisTemplate.opsForValue().set(CacheConsts.IMAGE_CODE+token, imageCodeService.getText(), 60 * 2, TimeUnit.SECONDS);
    }

}
