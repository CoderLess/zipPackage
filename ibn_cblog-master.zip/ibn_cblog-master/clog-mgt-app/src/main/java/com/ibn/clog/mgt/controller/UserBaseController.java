package com.ibn.clog.mgt.controller;

import com.ibn.clog.mgt.constant.CacheConsts;
import com.ibn.clog.mgt.service.CommonBaseService;
import com.ibn.clog.mgt.service.UserBaseService;
import com.ibn.clog.mgt.vo.UserBaseVO;
import com.ibn.entity.ResultInfo;
import com.ibn.exception.IbnException;
import com.ibn.ienum.HeaderEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.controller
 * @author： RenBin
 * @createTime：2019/12/18 8:39
 */
@Api(value = "用户服务基础接口", tags = "用户服务基础接口")
@RestController
@RequestMapping("users")
public class UserBaseController {
    @Autowired
    private UserBaseService userBaseService;
    @Autowired
    private CommonBaseService commonBaseService;

    @ApiOperation(value = "用户注册", notes = "用户注册")
    @RequestMapping(method = RequestMethod.POST, path = "register")
    public ResultInfo<Object> register(@RequestBody UserBaseVO userBaseVO, HttpServletRequest request) {
        // 校验信息
        if (null == userBaseVO) {
            return new ResultInfo<>().error("注册失败,用户信息异常");
        }
        if (!userBaseVO.getPassWord().equals(userBaseVO.getRepassWord())) {
            return new ResultInfo<>().error("两次密码不一致,请重新输入");
        }
        String token = request.getHeader(HeaderEnum.AUTHORIZATION.getValues());
        String imageCode = userBaseVO.getValidateCode();
        if (!commonBaseService.checkImageCode(CacheConsts.IMAGE_CODE+token, imageCode)) {
            return new ResultInfo<>().error("验证码输入错误请重新输入");
        }
        // 用户注册信息保存
        try {
            userBaseService.userRegister(userBaseVO);
        } catch (IbnException e) {
            return new ResultInfo<>().error(e.getMessage());
        }
        return new ResultInfo<>().success("注册成功");
    }

    @ApiOperation(value = "用户登入", notes = "用户登入")
    @RequestMapping(method = RequestMethod.POST, path = "login")
    public ResultInfo<Object> login(@RequestBody UserBaseVO userBaseVO, HttpServletRequest request) {
        String token = request.getHeader(HeaderEnum.AUTHORIZATION.getValues());
        String imageCode = userBaseVO.getValidateCode();
        if (!commonBaseService.checkImageCode(CacheConsts.IMAGE_CODE+token, imageCode)) {
            return new ResultInfo<>().error("验证码输入错误请重新输入");
        }
        try {
            if (userBaseService.userLogin(userBaseVO)) {
                return new ResultInfo<>().success("用户登入成功");
            }
        } catch (IbnException e) {
            return new ResultInfo<>().error("用户登入失败");
        }
        return new ResultInfo<>().error("用户名或密码错误");
    }

}
