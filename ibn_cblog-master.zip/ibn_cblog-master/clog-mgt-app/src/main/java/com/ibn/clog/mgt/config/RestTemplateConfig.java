package com.ibn.clog.mgt.config;

import com.ibn.clog.mgt.util.MyRestTemplate;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * @version 1.0
 * @description:
 * @projectName：cblog
 * @see: com.ibn.clog.config
 * @author： RenBin
 * @createTime：2019/12/11 11:12
 */
@Configuration
public class RestTemplateConfig {
    @Bean
    @LoadBalanced
    public RestTemplate createClient() {
        return new RestTemplate();
//        return new MyRestTemplate();
    }
}
