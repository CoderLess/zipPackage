package com.ibn.clog.mgt.service;

import com.ibn.clog.crm.domain.UserBaseDTO;
import com.ibn.clog.mgt.vo.UserBaseVO;
import com.ibn.exception.IbnException;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.mgt.service
 * @author： RenBin
 * @createTime：2019/12/18 9:21
 */
public interface UserBaseService {
    /**
     * @description: 用户注册相关信息
     * @author：RenBin
     * @createTime：2019/12/18 9:23
     */
    void userRegister(UserBaseVO userBaseVO) throws IbnException;
    /**
     * @description: 用户登入接口
     * @author：RenBin
     * @createTime：2019/12/19 17:40
     */
    Boolean userLogin(UserBaseVO userBaseVO) throws IbnException;
}
