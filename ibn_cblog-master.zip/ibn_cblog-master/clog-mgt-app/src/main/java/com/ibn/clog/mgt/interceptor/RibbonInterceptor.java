package com.ibn.clog.mgt.interceptor;

import com.ibn.clog.mgt.util.MyRestTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.article.interceptor
 * @author： RenBin
 * @createTime：2019/12/16 16:08
 */

public class RibbonInterceptor implements HandlerInterceptor {
    private static final Logger log = LoggerFactory.getLogger(RibbonInterceptor.class);

    private MyRestTemplate myRestTemplate;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
                             Object handler) {
        String lpfId = request.getHeader("lpf");
        // 解决service为null无法注入问题
        if (myRestTemplate == null) {
            BeanFactory factory =
                    WebApplicationContextUtils.getRequiredWebApplicationContext(request.getServletContext());
            myRestTemplate = (MyRestTemplate) factory.getBean("myRestTemplate");
        }

        myRestTemplate.header("lpf", lpfId);

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
                           ModelAndView modelAndView){
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
                                Object handler, Exception ex) {
    }
}
