package com.ibn.clog.mgt.constant;

/**
 * @version 1.0
 * @description: 系统配置相关常量
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.mgt.constant
 * @author： RenBin
 * @createTime：2019/12/19 8:50
 */
public class ConfigConsts {
}
