package com.ibn.clog.mgt.controller;

import com.ibn.clog.article.domain.ArticleDTO;
import com.ibn.entity.ResultInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * @version 1.0
 * @description:
 * @projectName：cblog
 * @see: com.ibn.clog.controller
 * @author： RenBin
 * @createTime：2019/12/9 11:59
 */
@RestController
@RequestMapping("articles")
public class AtricleController {
    @Autowired
    private RestTemplate restTemplate;
    private static final String ARTICLE_ROOT = "http://ARTICLE-PROVIDER/";
    @RequestMapping(method = RequestMethod.GET)
    public ResultInfo<String> saveArticle() {
        ResultInfo<String> resultInfo = null;
        try {
            resultInfo=restTemplate.getForObject(new URI(ARTICLE_ROOT+"articles"), ResultInfo.class);
        } catch (URISyntaxException e) {
            resultInfo.error("获取信息失败");
        }
        return resultInfo;
    }
    @RequestMapping(method = RequestMethod.POST)
    public ResultInfo<String> saveArticle(@RequestBody ArticleDTO articleDTO) {
        ResultInfo<String> resultInfo;
        try {
            System.out.println(articleDTO);
            resultInfo=restTemplate.postForObject(new URI(ARTICLE_ROOT + "articles"), articleDTO, ResultInfo.class);
        } catch (Exception e) {
            resultInfo=new ResultInfo<>().error("获取信息失败");
            e.printStackTrace();
        }
        return resultInfo;
    }
}
