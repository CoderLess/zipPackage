package com.ibn.clog.mgt;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * @version 1.0
 * @description:
 * @projectName：cblog
 * @see: com.ibn.clog
 * @author： RenBin
 * @createTime：2019/12/11 11:12
 */
@EnableEurekaClient
@SpringBootApplication
@PropertySource({
        "classpath:clog.properties"
})
public class ClogMgtAppApplication {
    private static final Logger logger = LoggerFactory.getLogger(ClogMgtAppApplication.class);
    private static final String SERVER_PORT = "server.port";
    public static void main(String[] args) throws UnknownHostException {
        ConfigurableApplicationContext application = SpringApplication.run(ClogMgtAppApplication.class, args);
        Environment env = application.getEnvironment();
        logger.info("\n----------------------------------------------------------\n\t" +
                        "Application '{}' is running! Access URLs:\n\t" +
                        "External: \thttp://{}:{}\n\t"+
                        "API测试: \thttp://{}:{}/swagger-ui.html\n\t"+
                        "API文档: \thttp://{}:{}/doc.html\n"+
                        "----------------------------------------------------------",
                env.getProperty("spring.application.name"),
                InetAddress.getLocalHost().getHostAddress(),
                env.getProperty(SERVER_PORT),
                InetAddress.getLocalHost().getHostAddress(),
                env.getProperty(SERVER_PORT),
                InetAddress.getLocalHost().getHostAddress(),
                env.getProperty(SERVER_PORT));
    }

}
