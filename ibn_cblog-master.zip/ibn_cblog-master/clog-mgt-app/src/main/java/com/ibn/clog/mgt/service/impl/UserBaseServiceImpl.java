package com.ibn.clog.mgt.service.impl;

import com.alibaba.fastjson.JSON;
import com.ibn.clog.crm.domain.UserBaseDTO;
import com.ibn.clog.mgt.service.UserBaseService;
import com.ibn.clog.mgt.vo.UserBaseVO;
import com.ibn.entity.ResultInfo;
import com.ibn.exception.IbnException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * @version 1.0
 * @description:
 * @projectName：ibn_cblog
 * @see: com.ibn.clog.mgt.service.impl
 * @author： RenBin
 * @createTime：2019/12/18 9:22
 */
@Service("userBaseService")
public class UserBaseServiceImpl implements UserBaseService {
    private static final Logger logger = LoggerFactory.getLogger(UserBaseServiceImpl.class);
    private static final String USER_BASE_ROOT = "http://CRM-PROVIDER/";
    @Autowired
    private RestTemplate restTemplate;

    @Override
    public void userRegister(UserBaseVO userBaseVO) throws IbnException {
        if (null == userBaseVO) {
            throw new IbnException("参数异常");
        }
        try {
            restTemplate.postForObject(new URI(USER_BASE_ROOT + "users"), userBaseVO, ResultInfo.class);
        } catch (URISyntaxException e) {
            String msg = String.format("用户注册请求异常:%s", JSON.toJSONString(userBaseVO));
            logger.error(msg, e);
            throw new IbnException("用户注册失败");
        }
    }

    @Override
    public Boolean userLogin(UserBaseVO userBaseVO) throws IbnException {
        if (null == userBaseVO) {
            throw new IbnException("参数异常");
        }
        UserBaseDTO userBaseDTO = new UserBaseDTO();
        BeanUtils.copyProperties(userBaseVO,userBaseDTO);
        ResultInfo<UserBaseDTO> resultInfo;
        try {
            resultInfo = restTemplate.getForObject(USER_BASE_ROOT + "users?userName={userName}&passWord={passWord}",
                    ResultInfo.class, userBaseDTO.getUserName(),userBaseDTO.getPassWord());
        } catch (Exception e) {
            String msg = String.format("查询接口异常:{}", JSON.toJSONString(userBaseVO));
            logger.error(msg,e);
            throw new IbnException("查询接口异常");
        }
        if (null == resultInfo) {
            return false;
        }
        return resultInfo.getData()!=null;
    }
}
