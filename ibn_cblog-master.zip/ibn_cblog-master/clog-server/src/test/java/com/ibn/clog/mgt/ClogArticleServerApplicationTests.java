package com.ibn.clog.mgt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClogArticleServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
