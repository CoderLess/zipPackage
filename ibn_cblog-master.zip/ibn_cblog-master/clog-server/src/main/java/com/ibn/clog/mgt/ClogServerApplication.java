package com.ibn.clog.mgt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class ClogServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClogServerApplication.class, args);
    }

}
