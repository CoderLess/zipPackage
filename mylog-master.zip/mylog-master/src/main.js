import Vue from 'vue'
import App from './App.vue'
import './plugins/axios.js'
import './plugins/element-ui.js'

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
