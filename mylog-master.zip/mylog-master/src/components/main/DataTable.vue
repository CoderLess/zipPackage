<template>
  <div id="content">
    <el-table :data="tableData" style="width: 100%" @expand-change="expandSelect">
      <el-table-column type="expand">
        <template slot-scope="props">
          <!-- type===1 菜单 -->
          <template v-if="props.row.type===1">
            <data-table :tableData="props.row.subMenuList"></data-table>
          </template>
          <template v-else-if="props.row.type===2">
            <el-form label-position="left" inline class="demo-table-expand">
              <el-form-item label="详情">
                <span v-html="props.row.content"></span>
              </el-form-item>
            </el-form>
          </template>
        </template>
      </el-table-column>
      <el-table-column label="类型/标题" prop="name"></el-table-column>
      <el-table-column label="描述" prop="explicate"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            size="mini"
            v-if="scope.row.type===1"
            type="success"
            @click="handleAdd(scope.row.id)"
          >添加</el-button>
          <el-button size="mini" type="primary" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 添加弹出框 -->
    <el-dialog title="添加" :visible.sync="addArticleDialogVisible">
      <el-form :model="addData" ref="addArticleForm">
        <el-form-item label="类型/标题" prop="name">
          <el-input v-model="addData.name"></el-input>
        </el-form-item>
        <el-form-item label="描述" prop="explicate">
          <el-input v-model="addData.explicate"></el-input>
        </el-form-item>
        <el-form-item label="类别">
          <el-radio-group v-model="addData.type" size="medium">
            <el-radio border label="1">类型</el-radio>
            <el-radio border label="2">标题</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form v-if="parseInt(addData.type)===2" label="内容">
          <el-input type="textarea" :rows="50" placeholder="请输入内容" v-model="addData.content"></el-input>
        </el-form>
        <el-form-item class="btnRow">
          <el-button type="primary" @click="addArticle('addArticleForm')">保存</el-button>
          <el-button @click="addArticleDialogVisible=false">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 编辑弹出框 -->
    <el-dialog title="添加" :visible.sync="editArticleDialogVisible">
      <el-form :model="addData" ref="editArticleForm">
        <el-form-item label="类型/标题" prop="name">
          <el-input v-model="editData.name"></el-input>
        </el-form-item>
        <el-form-item label="描述" prop="explicate">
          <el-input v-model="editData.explicate"></el-input>
        </el-form-item>
        <el-form-item label="类别">
          <el-radio-group v-model="editData.type" size="medium" disabled>
            <el-radio border :label="1">类型</el-radio>
            <el-radio border :label="2">标题</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form v-if="parseInt(editData.type)===2" label="内容">
          <el-input type="textarea" :rows="50" placeholder="请输入内容" v-model="editData.content"></el-input>
        </el-form>
        <el-form-item class="btnRow">
          <el-button type="primary" @click="editArticle('editArticleForm')">保存</el-button>
          <el-button @click="editArticleDialogVisible=false">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<style>
#content {
  text-align: left;
}
.btnRow {
  margin-top: 20px;
  text-align: center;
}
</style>

<script>
export default {
  name: "dataTable",
  props: {
    tableData: {},
  },
  data() {
    return {
      // 控制添加表单是否显示
      addArticleDialogVisible: false,
      // 添加表单对应的数据
      addData: {
        parentId: 0,
        name: '',
        explicate: '',
        type: 0,
        content: ''
      },
      // 控制编辑表单是否显示
      editArticleDialogVisible: false,
      editData: {},
    }
  },
  methods: {
    // 点击展开按钮
    async expandSelect(row) {
      if (row.type === 2 && !row.content) {
        const { data: res } = await this.$http.get('/articles/' + row.articleId)
        row.content = res.response.content
      }
    },
    // 点击添加按钮
    handleAdd(id) {
      this.addArticleDialogVisible = true
      this.addData.parentId = id
    },
    // 添加文章
    async addArticle(formName) {
      const { data: res } = await this.$http.put('/articles', this.addData)
      if (res.status === 200) {
        this.addArticleDialogVisible = false
        this.resetForm(formName)
        this.$message.success(res.message)
        this.$emit('getMenuList');
      } else {
        this.$message.success(res.message)
      }
    },
    // 表单重置功能
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    // 点击编辑文章按钮
    handleEdit(data) {
      this.editData = data
      this.editArticleDialogVisible = true
    },
    // 点击保存编辑按钮
    async editArticle(formName) {
      const { data: res } = await this.$http.post('/articles', this.editData)
      if (res.status === 200) {
        this.editArticleDialogVisible = false
        this.resetForm(formName)
        this.$message.success(res.message)
        this.$emit('getMenuList');
      } else {
        this.$message.error(res.message)
      }
    },
    // 点击删除按钮
    handleDelete(data) {
      if (data.subMenuList.length < 1 || (data.type == 2 && data.subMenuList.length == 1)) {
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$http.delete('/menus/' + data.id).then(res => {
            if (res.data.status === 200) {
              this.$message.success(res.data.message)
            } else {
              this.$message.error(res.data.message)
            }
          }).catch(err => {
            this.$message.error(err)
          })
        }).catch(() => {
          this.$message.info('已取消删除')
        })
      } else {
        this.$message.info(data.name + ' 有子节点无法删除')
      }

    }
  }
}
</script>