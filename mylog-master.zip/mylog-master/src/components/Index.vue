<template>
  <div>
    <el-button @click="handleAdd(0)">添加</el-button>
    <data-table :tableData="tableData" @getMenuList="getMenuList" ref="dataTable"></data-table>
  </div>
</template>

<script>
import DataTable from './main/DataTable'
export default {
  components: {
    DataTable
  },
  data() {
    return {
      tableData: []
    }
  },

  methods: {
    async getMenuList() {
      const { data: res } = await this.$http.get('/menus/list')
      this.tableData = res.response
    },
    handleAdd(data) {
      this.$refs.dataTable.handleAdd(data);
    }
  },
  created() {
    this.getMenuList()
  }

}

</script>
<style lang='less' scoped>
</style>