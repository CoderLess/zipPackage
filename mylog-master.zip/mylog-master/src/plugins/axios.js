import Vue from 'vue'
import Axios from 'axios'

Axios.defaults.baseURL='http://localhost:8081'
Vue.prototype.$http=Axios