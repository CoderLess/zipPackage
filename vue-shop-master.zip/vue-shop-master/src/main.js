import Vue from 'vue'
import App from './App.vue'
import router from './router/router.js'
import './plugins/element.js'
// 导入全局样式
import './assets/css/global.css'
// 导入字体图标
import './assets/fonts/iconfont.css'
// axios
import axios from 'axios'
// 配置请求的根路径
axios.defaults.baseURL = 'http://localhost:8081/'
axios.interceptors.request.use(config => {
  config.headers.Authorization = window.sessionStorage.getItem('token')
  return config
})
Vue.prototype.$http = axios

Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
