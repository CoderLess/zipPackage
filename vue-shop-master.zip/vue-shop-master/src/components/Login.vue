<template>
  <div class="login-container">
    <!-- 登入框 -->
    <div class="login-box">
      <!-- 头像框 -->
      <div class="avatar-box">
        <img src="../assets/logo.png"
             alt />
      </div>
      <!-- 表单框 -->
      <el-form ref="loginFormRef"
               :model="loginForm"
               label-width="0px"
               class="login-info"
               :rules="loginFormRules">
        <!-- 用户名输入框 -->
        <el-form-item prop="userName">
          <el-input prefix-icon="iconfont icon-user"
                    v-model="loginForm.userName"></el-input>
        </el-form-item>
        <!-- 密码输入框 -->
        <el-form-item prop="passWord">
          <el-input prefix-icon="iconfont icon-3702mima"
                    v-model="loginForm.passWord"
                    type="password"></el-input>
        </el-form-item>
        <el-form-item class="btns">
          <el-button type="primary"
                     @click="login">登入</el-button>
          <el-button type="info"
                     @click="restLoginForm">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      // 登入表单绑定数据
      loginForm: {
        userName: 'zhangsan',
        passWord: '123456'
      },
      // 表单验证规则
      loginFormRules: {
        userName: [
          { required: true, message: '请输入用户名称', trigger: 'blur' },
          { min: 6, max: 15, message: '长度在 6 到 15 个字符', trigger: 'blur' }
        ],
        passWord: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 6, max: 50, message: '长度在 6 到 30 个字符', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    // 重置
    restLoginForm () {
      this.$refs.loginFormRef.resetFields()
    },
    // 登入
    login () {
      this.$refs.loginFormRef.validate(async valid => {
        if (!valid) return
        const { data: res } = await this.$http.post('user/userLogin', this.loginForm)
        if (res.meta.status !== 200) return this.$message.error('登入失败')
        this.$message.success('登入成功')
        window.sessionStorage.setItem('token', res.data.token)
        this.$router.push('/home')
      })
    }
  }
}
</script>
<style lang="less" scoped>
.login-container {
  background-color: #2b4b6b;
  height: 100%;
}
.login-box {
  width: 450px;
  height: 300px;
  position: absolute;
  background-color: #ffffff;
  border-radius: 3px;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  .avatar-box {
    height: 130px;
    width: 130px;
    border: 1px solid #eee;
    border-radius: 50%;
    padding: 10px;
    box-shadow: 0 0 10px #ddd;
    position: absolute;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #fff;
    img {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background-color: #eee;
    }
  }
}
.btns {
  display: flex;
  justify-content: flex-end;
}
.login-info {
  position: absolute;
  bottom: 0;
  width: 100%;
  padding: 0 20px;
  box-sizing: border-box;
}
</style>
