<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator="/">
      <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>用户管理</el-breadcrumb-item>
      <el-breadcrumb-item>我的用户</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 卡片区 -->
    <el-card class="box-card">
      <!-- 添加用户对话框区域 -->
      <el-dialog title="添加用户" @close="addUserFormClose" :visible.sync="dialogVisible" width="50%">
        <el-form
          ref="addUserFormRef"
          :rules="addUserFormRules"
          :model="addUserForm"
          label-width="70px"
        >
          <el-form-item label="用户名" prop="userName">
            <el-input v-model="addUserForm.userName"></el-input>
          </el-form-item>
          <el-form-item label="用户昵称" prop="nickName">
            <el-input v-model="addUserForm.nickName"></el-input>
          </el-form-item>
          <el-form-item label="真实姓名" prop="realName">
            <el-input v-model="addUserForm.realName"></el-input>
          </el-form-item>
          <!-- <el-form-item label="性别" prop="sex">
            <el-input v-model="addUserForm.sex"></el-input>
          </el-form-item>-->
          <el-form-item label="手机号" prop="mobile">
            <el-input v-model="addUserForm.mobile"></el-input>
          </el-form-item>
          <el-form-item label="邮箱" prop="email">
            <el-input v-model="addUserForm.email"></el-input>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="addUser">确 定</el-button>
        </span>
      </el-dialog>
      <!-- 修改用户对话框区域 -->
      <el-dialog
        title="修改用户"
        :visible.sync="editUserDialogVisible"
        width="50%"
        @close="editUserDialogClose"
      >
        <el-form
          ref="editUserFormRef"
          :rules="editUserFormRule"
          :model="editUserForm"
          label-width="70px"
        >
          <el-form-item label="用户名" prop="userName">
            <el-input v-model="editUserForm.userName" disabled></el-input>
          </el-form-item>
          <el-form-item label="用户昵称" prop="nickName">
            <el-input v-model="editUserForm.nickName"></el-input>
          </el-form-item>
          <el-form-item label="真实姓名" prop="realName">
            <el-input v-model="editUserForm.realName"></el-input>
          </el-form-item>
          <el-form-item label="手机号" prop="mobile">
            <el-input v-model="editUserForm.mobile"></el-input>
          </el-form-item>
          <el-form-item label="邮箱" prop="email">
            <el-input v-model="editUserForm.email"></el-input>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button @click="editUserDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="editUser">确 定</el-button>
        </span>
      </el-dialog>
      <!-- 搜索与添加区域 -->
      <el-row :gutter="20">
        <el-col :span="9">
          <el-input
            placeholder="请输入内容"
            v-model="queryInfo.userNameLike"
            clearable
            @clear="getUserList"
          >
            <el-button slot="append" icon="el-icon-search" @click="search"></el-button>
          </el-input>
        </el-col>
        <el-col :span="4">
          <el-button type="primary" @click="addUserBtn">添加用户</el-button>
        </el-col>
      </el-row>
      <!-- 用户数据表格区域 -->
      <el-table :data="userList" border stripe>
        <el-table-column prop="id" label="id"></el-table-column>
        <el-table-column prop="userName" label="用户名"></el-table-column>
        <el-table-column prop="nickName" label="用户昵称"></el-table-column>
        <el-table-column prop="realName" label="真实姓名"></el-table-column>
        <el-table-column prop="sex" label="性别"></el-table-column>
        <el-table-column prop="mobile" label="手机号"></el-table-column>
        <el-table-column prop="email" label="邮箱"></el-table-column>
        <el-table-column label="是否禁用">
          <template slot-scope="scope">
            <el-switch v-model="scope.row.disabled" @change="userStatusChange(scope.row)"></el-switch>
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="primary" icon="el-icon-edit" circle @click="userEditBtn(scope.row.id)"></el-button>
            <el-button
              type="danger"
              icon="el-icon-delete"
              circle
              @click="userDeleteBtn(scope.row.id)"
            ></el-button>
            <el-tooltip effect="dark" content="设置权限" placement="top" :enterable="false">
              <el-button type="warning" icon="el-icon-setting" circle></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
      <!-- 页码区域 -->
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="queryInfo.pageNum"
        :page-sizes="[1, 2, 3, 4]"
        :page-size="queryInfo.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      ></el-pagination>
    </el-card>
  </div>
</template>
<script>
export default {

  data() {
    // 自定义校验规则
    // 检查邮箱格式是否正确
    var checkEmail = (rule, value, callback) => {
      const regEmail = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/
      if (regEmail.test(value)) {
        return callback()
      }
      callback(new Error('请输入合法的邮箱'))
    }
    // 检查手机号格式是否正确
    var checkMobile = (rule, value, callback) => {
      const regMobile = /^1[3456789]\d{9}$/
      if (regMobile.test(value)) {
        return callback()
      }
      callback(new Error('请输入合法的手机号'))
    }
    return {
      queryInfo: {
        userNameLike: '',
        pageSize: 1,
        pageNum: 1
      },
      userList: [],
      total: 0,
      // 控制添加用户的对话框显示与隐藏
      dialogVisible: false,
      addUserForm: {
        userName: '',
        nickName: '',
        realName: '',
        // sex: '',
        mobile: '',
        email: ''
      },
      addUserFormRules: {
        userName: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
        ],
        nickName: [
          { required: true, message: '请输入用户昵称', trigger: 'blur' },
          { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
        ],
        realName: [
          { required: true, message: '请输入真实姓名', trigger: 'blur' },
          { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
        ],
        // sex: [
        //   { required: true, message: '请输入性别', trigger: 'blur' },
        //   { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
        // ],
        mobile: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          { validator: checkMobile, trigger: 'blur' }
        ],
        email: [
          { required: true, message: '请输入邮箱', trigger: 'blur' },
          { validator: checkEmail, trigger: 'blur' }
        ]
      },
      editUserDialogVisible: false,
      editUserForm: {},
      editUserFormRule: {
        nickName: [
          { required: true, message: '请输入用户昵称', trigger: 'blur' },
          { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
        ],
        realName: [
          { required: true, message: '请输入真实姓名', trigger: 'blur' },
          { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
        ],
        mobile: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          { validator: checkMobile, trigger: 'blur' }
        ],
        email: [
          { required: true, message: '请输入邮箱', trigger: 'blur' },
          { validator: checkEmail, trigger: 'blur' }
        ]
      }
    }
  },
  created() {
    this.getUserList()
  },
  methods: {
    // 获取用户列表中的数据
    async getUserList() {
      console.log(this.queryInfo)
      const { data: res } = await this.$http.get('user/users', { params: this.queryInfo })
      if (res.meta.status !== 200) return this.$message.error(res.meta.message)
      this.userList = res.data.list
      this.total = res.data.total
    },
    // 条数改变
    handleSizeChange(pageSize) {
      this.queryInfo.pageSize = pageSize
      this.getUserList()
    },
    // 改变页数
    handleCurrentChange(pageNum) {
      this.queryInfo.pageNum = pageNum
      this.getUserList()
    },
    // 用户状态修改
    async userStatusChange(rowData) {
      const { data: res } = await this.$http.put(`user/${rowData.id}/disabled/${rowData.disabled}`)
      if (res.meta.status === 200) {
        return this.$message.success(res.meta.message)
      }
      return this.$message.error(res.meta.message)
    },
    // 点击搜索按钮
    search() {
      this.getUserList()
    },
    // 点击添加用户按钮
    addUserBtn() {
      this.dialogVisible = true
    },
    // 关闭添加用户弹窗时重置所有属性
    addUserFormClose() {
      this.$refs.addUserFormRef.resetFields()
    },
    // 添加用户
    addUser() {
      // 提交之前的预校验操作
      this.$refs.addUserFormRef.validate(async valid => {
        if (!valid) return
        // 发起请求,添加用户
        const { data: res } = await this.$http.post('user/add', this.addUserForm)
        if (res.meta.status !== 200) return this.$message.error(res.meta.message)
        this.$message.success(res.meta.message)
        // 关闭添加用户弹出框
        this.dialogVisible = false
        // 重新获取一下用户列表
        this.getUserList()
      })
    },
    // 编辑用户按钮
    async userEditBtn(id) {
      const { data: res } = await this.$http.get('user/queryUserBaseById/' + id)
      if (res.meta.status !== 200) return this.$message.error(res.meta.message)
      this.editUserForm = res.data
      this.editUserDialogVisible = true
    },
    // 修改用户对话框的关闭
    editUserDialogClose() {
      this.$refs.editUserFormRef.resetFields()
    },
    // 修改用户信息
    editUser() {
      this.$refs.editUserFormRef.validate(async valid => {
        if (!valid) return
        // 发起网络请求
        const { data: res } = await this.$http.put('user/modify/' + this.editUserForm.id, this.editUserForm)
        // 出现错误
        if (res.meta.status !== 200) return this.$message.error(res.meta.message)
        // 重新获取一下列表信息
        this.getUserList()
        // 关闭弹出窗
        this.editUserDialogVisible = false
        this.$message.success(res.meta.message)
      })
    },
    // 删除对应的用户
    async userDeleteBtn(id) {
      const res = await this.$confirm('此操作将永久删除该用户, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).catch(error => error)
      if (res !== 'confirm') {
        return this.$message.success('取消对用户删除操作')
      }
      const { data: result } = await this.$http.delete('user/delete/' + id)
      if (result.meta.status !== 200) return this.$message.error(result.meta.message)
      this.getUserList()
      this.$message.success('用户删除成功')
    }
  }
}
</script>
<style lang="less" scoped>
.el-table {
  margin-top: 15px;
  font-size: 15px;
}
</style>
